# Independent content review

For faithful image recreation and scoped edits, prioritize source fidelity and the
authorized change. Compare directly with the original when supplied. Inherited
source ambiguities, experimental gaps and unrelated scientific/style improvements
are suggestions, not delivery blockers. Required findings must identify introduced
errors, missing requested content, unreadability or broken requested native behavior.
Do not turn a conversion into an unrequested rewrite. Keep the report concise.

Use a fresh context without the author's conversation, outline, research notes,
rationale or self-assessment. Do not edit the deck. First principle: the deck exists to get its message
across; ask of each page whether this audience would grasp its point quickly and correctly. Also ask what each page teaches: a page that only restates what is visible, or a deck that
leaves out what an informed presenter would cover, is a substance finding with the missing facts named.

First read every page in order from the actual audience surface. Self-reading must
work without hidden notes. A live deck may include a real supplied script; never
invent a presenter who fills every gap. Record concrete page evidence:
- Entry: purpose, starting point, unexplained terms/people/symbols/units.
- Continuity: missing premises, definitions, causal steps or unsupported conclusions.
- Substance: useful knowledge, evidence, method, judgment or earned emotion;
  paraphrased headings are not depth.
- Concreteness: examples, source passages, scenarios, comparisons or worked steps
  that actually explain the abstraction.
- Load: too many unfamiliar concepts together, or brevity removing explanation.
- Natural questions: conditions after benefits, application after methods, evidence
  after assertions, choices and consequences beyond chronology.
- Closing: specific understanding/feeling, answered promises, visible boundaries.

Only after first-pass findings inspect the original brief and necessary sources.
When the host supplies a sealed independent `first-view.json`, that audience
reading has already happened. In the source-evidence context, check all pages'
claims against the actual brief and sources using complete extracted text and
the actual images wherever a diagram, spatial meaning or uncertainty requires it.
Resolve unsupported blind assumptions directly; do not repeat its full design/
comprehension reading or rebuild host-prepared inventories and contact sheets.
Check required coverage, accuracy, data/units, examples, quotes, uncertainty,
attribution and scope. Separate source errors from author errors. Do not demand
unrequested topics or novel opinions from a lesson.

Report pages, observation, audience consequence, evidence and repair. Mark required
corrections versus suggestions. Required means the audience would learn or act on a
false fact, a missing requested item or an unreadable statement. Information the user
never supplied and the author cannot verify (a brand name, contact details, prices,
the user's own figures) is never required. The author fills the user's own figures with
plausible illustrative values labelled on the page ("示例数字，非真实数据" / "Illustrative
figure"); check that the label is present, the values are internally consistent and no
external fact is invented, and suggest which values the user should replace. An
unlabelled invented figure, or an invented external fact, is required. Wording that could be
more precise, an inference that could be hedged better, or extra scholarly nuance is a
suggestion. The first review is the complete pass: check every page's claims, map labels,
picture callouts and question/answer pairs now and report all required issues together,
because the author fixes them in one revision. On a re-review, a new required finding must
concern a page the revision changed or an error it introduced; do not raise the precision
bar on unchanged text. State actual coverage and unreadable/untested parts.
No finding quota or numerical taste score. Text/thumbnails alone are insufficient.
Follow the host JSON schema where supplied. Recheck actual revised pages and their
context; an author's resolution claim is not verification.
# Source meaning during visual simplification

Compare source evidence directly before calling a mismatch required. Check example labels, scope and conditions, units, numerical qualifiers, symbols, operation order, actors, and input/output direction. A cleaner diagram must retain “example” and “e.g.” when the source uses illustrative values. Missing qualifiers can turn a correct example into a false general claim. Identify the source location and affected slide text/connection in the finding. For faithful conversion or scoped edits, inherited scientific ambiguities remain suggestions; do not require rewriting the supplied source.


# Finding route

Select one route per finding from workflow-branches.md: content_revision for facts,
source evidence or explanation; native_repair for layout/fonts/captions/asset
placement/native behavior without new content research; retain_suggestion for a
nonblocking refinement. Classify by the action needed, not your reviewer role.
A required finding cannot select retain_suggestion. Existing bounded review and
source-fidelity rules still apply; no additional review pass.
