#!/usr/bin/env python3
from pptx_core.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
