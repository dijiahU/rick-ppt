"""One optional designer response inside the existing bounded repair loop.

Only a host review receipt authorizes this route. Suggestions remain optional;
neither their number nor the designer's taste becomes a new delivery gate.
"""
import hashlib
import base64
import json
import os
from pathlib import Path
import re
import shutil
import uuid

from design_roles import enabled
from progress import read_scoped

POLICY={'version':1,'max_passes':1}
# Finishing polish (Rick, 2026-11-21): a passed review used to deliver its directly fixable
# suggestions (overflow, a numbered sequence turned into bullets, uneven sizes) unchanged.
# One short author pass now applies them, then a normal review checks the new bytes; any
# required finding in that review restores the passed version.
POLISH={'version':1,'max_passes':1}
# Reviewers often file a plainly fixable visual defect (a unit glyph colliding with its number)
# as retain_suggestion, so visual suggestions of either route qualify; content suggestions
# only when routed to a native fix (content_revision needs source work, not polish).
POLISH_ROUTES={'visual':('native_repair','retain_suggestion'),'content':('native_repair',)}


def polish_findings(receipt):
    findings=[f for kind in ('content','visual') for f in receipt[kind]['findings']]
    if any(f.get('severity')=='required' for f in findings):return []
    return [f for kind in ('content','visual') for f in receipt[kind]['findings']
            if f.get('severity')=='suggestion' and f.get('route') in POLISH_ROUTES[kind]]


def polish_response(receipt):
    try:
        return (receipt.get('polish_response')==POLISH and receipt.get('review_mode')=='substantive' and
                type(receipt.get('round')) is int and receipt['round']<3 and
                type(receipt.get('input_revision')) is int and bool(polish_findings(receipt)))
    except (KeyError,TypeError):
        return False


def transactional(receipt):
    """A receipt whose candidate may be replaced by a bounded pass and restored."""
    return optional_response(receipt) or polish_response(receipt)


def mark_response(cfg,receipt,*,scoped):
    from design_completion import CONTRACT,response_needed
    if receipt.get('design_completion')==CONTRACT:
        if (enabled(cfg) and not scoped and receipt.get('round')==1
                and response_needed(receipt)):
            receipt['designer_response']=dict(POLICY)
        return _mark_polish(cfg,receipt,scoped=scoped)
    if (enabled(cfg) and not scoped and receipt.get('round')==1 and
            any(f.get('severity')=='suggestion' for f in receipt['visual']['findings'])):
        receipt['designer_response']=dict(POLICY)
    return _mark_polish(cfg,receipt,scoped=scoped)


def _mark_polish(cfg,receipt,*,scoped):
    if (cfg.get('polish_pass',True) and enabled(cfg) and not scoped and 'designer_response' not in receipt and
            type(receipt.get('round')) is int and receipt['round']<3 and polish_findings(receipt)):
        receipt['polish_response']=dict(POLISH)
    return receipt


def host_authorized_response(receipt):
    marker=receipt.get('designer_response')
    from design_completion import CONTRACT,readiness,response_needed,response_findings
    if not (isinstance(marker,dict) and marker==POLICY and type(marker.get('version')) is int and
            receipt.get('round')==1 and receipt.get('review_mode')=='substantive' and
            type(receipt.get('input_revision')) is int and isinstance(receipt.get('plugin_version'),str)):
        return False
    try:
        if receipt.get('design_completion')==CONTRACT:
            if not response_needed(receipt):return False
            if readiness(receipt.get('visual',{}))=='needs_revision':
                ids=receipt['visual']['design_assessment'].get('primary_findings')
                if not ids or not set(ids)<={f['id'] for f in receipt['visual']['findings']}:return False
        return any(f.get('severity')=='suggestion' for f in response_findings(receipt))
    except (KeyError,TypeError,ValueError):
        return False


def optional_response(receipt):
    return (host_authorized_response(receipt) and
            not any(f.get('severity')=='required' for kind in ('content','visual') for f in receipt[kind]['findings']))


def capture_metadata(job):
    result={}
    for name in ('outline.json','source-notes.md','decision-plan.json'):
        try:result[name]=read_scoped(job,name,2*1024*1024)
        except FileNotFoundError:result[name]=None
    return result


def _current_identity(run):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,150}',run.task.get('id','')):raise ValueError('Invalid designer transaction task')
    state=run.journal.state if run.journal else {}
    return {'task_id':run.task['id'],'input_revision':state.get('input_revision',run.task.get('input_revision',0)),
            'author_completed_at':(state.get('completed_stages',{}).get('author') or {}).get('completed_at')}


def baseline_is_current(run,baseline):
    return baseline['identity']==_current_identity(run)


def save_baseline(run,artifact,receipt,rendered,review_states):
    """Host-private transaction baseline survives process loss and re-review."""
    records=Path(run.records).resolve(strict=True);job=Path(run.job).resolve(strict=True)
    if records.is_relative_to(job):raise ValueError('Designer baseline must be host private')
    digest=hashlib.sha256(artifact).hexdigest()
    if digest!=receipt['artifact_sha256'] or not transactional(receipt):raise ValueError('Unverified designer baseline')
    identity=_current_identity(run)
    if identity['input_revision']!=receipt['input_revision']:raise ValueError('Stale designer baseline')
    home=records/(run.task['id']+'-designer-baseline-'+digest)
    if not home.exists():
        temporary=records/('.designer-baseline-'+uuid.uuid4().hex);temporary.mkdir(mode=0o700)
        def put(name,body):
            with (temporary/name).open('xb') as stream:stream.write(body)
            (temporary/name).chmod(0o600)
            return {'file':name,'sha256':hashlib.sha256(body).hexdigest()}
        try:
            artifact_info=put('presentation.pptx',artifact)
            pages=[put('page-'+str(n)+'.png',Path(path).read_bytes()) for n,path in enumerate(rendered['pages'],1)]
            metadata=capture_metadata(job)
            value={'version':1,'identity':identity,'receipt':receipt,'artifact':artifact_info,'pages':pages,
                   'review_states':review_states,'metadata':{name:base64.b64encode(body).decode() if body is not None else None for name,body in metadata.items()}}
            binding={key:rendered[key] for key in ('source_hash','environment') if key in rendered}
            if binding:value['render_binding']=put('render-binding.json',json.dumps(binding,ensure_ascii=False).encode())
            put('baseline.json',json.dumps(value,ensure_ascii=False).encode())
            os.rename(temporary,home)
        except BaseException:
            shutil.rmtree(temporary,ignore_errors=True);raise
    baseline=_load_home(home)
    if baseline['identity']!=identity or baseline['receipt']!=receipt:raise ValueError('Designer baseline identity conflict')
    return baseline


def _load_home(home):
    if home.is_symlink():raise ValueError('Unsafe designer baseline')
    value=json.loads(read_scoped(home,'baseline.json',16*1024*1024))
    if value.get('version')!=1 or not transactional(value['receipt']):raise ValueError('Invalid designer baseline')
    def verified(info,limit):
        data=read_scoped(home,info['file'],limit)
        if hashlib.sha256(data).hexdigest()!=info['sha256']:raise ValueError('Designer baseline bytes changed')
        return data
    value['artifact_bytes']=verified(value['artifact'],80*1024*1024)
    if hashlib.sha256(value['artifact_bytes']).hexdigest()!=value['receipt']['artifact_sha256']:raise ValueError('Designer baseline review mismatch')
    for item in value['pages']:verified(item,80*1024*1024)
    value['rendered']={'pages':[str(home/item['file']) for item in value['pages']]}
    if value.get('render_binding'):
        binding=json.loads(verified(value['render_binding'],8*1024*1024))
        if not isinstance(binding,dict) or set(binding)-{'source_hash','environment'}:raise ValueError('Invalid saved render binding')
        value['rendered'].update(binding)
    value['metadata_bytes']={name:base64.b64decode(body,validate=True) if body is not None else None for name,body in value['metadata'].items()}
    value['home']=str(home)
    status=Path(home)/'outcome.json'
    outcome=json.loads(read_scoped(home,'outcome.json',10000)).get('status') if status.is_file() else None
    value['rolled_back']=outcome=='rolled_back'
    value['accepted']=outcome=='candidate_accepted'
    return value


def load_baseline(run):
    """Unambiguous host state only; task-local findings cannot create authority."""
    records=Path(run.records).resolve(strict=True);job=Path(run.job).resolve(strict=True)
    if records.is_relative_to(job):raise ValueError('Designer baseline must be host private')
    identity=_current_identity(run);matches=[]
    for home in records.glob(run.task['id']+'-designer-baseline-*'):
        value=_load_home(home)
        # An accepted candidate closed this optional transaction; later ordinary
        # repairs/reviews must not compare against or roll back to it.
        if value['identity']==identity and not value['accepted']:matches.append(value)
    if len(matches)>1:raise ValueError('Ambiguous designer transaction baseline')
    return matches[0] if matches else None


def _mark_outcome(baseline,status,**extra):
    home=Path(baseline['home'])
    temporary=home/('.outcome-'+uuid.uuid4().hex)
    with temporary.open('x') as stream:json.dump({'status':status,'artifact_sha256':baseline['receipt']['artifact_sha256'],**extra},stream)
    os.replace(temporary,home/'outcome.json')


def mark_rollback(baseline):
    _mark_outcome(baseline,'rolled_back')
    baseline['rolled_back']=True


def mark_accepted(baseline,candidate_sha256):
    _mark_outcome(baseline,'candidate_accepted',candidate_sha256=candidate_sha256)
    baseline['accepted']=True


def unchanged_pages(baseline_bytes,candidate_bytes):
    """Host-proven untouched pages; any parse doubt proves nothing."""
    try:
        from canvas_snapshot import native_pages
        from user_pages import fingerprint
        from review_comparison import globals_identity
        count=len(native_pages(candidate_bytes))
        if count!=len(native_pages(baseline_bytes)) or globals_identity(baseline_bytes)!=globals_identity(candidate_bytes):return set()
        return {page for page in range(1,count+1) if fingerprint(baseline_bytes,page)==fingerprint(candidate_bytes,page)}
    except Exception:
        return set()


def introduced_required(baseline_receipt,receipt,unchanged=frozenset()):
    """Required findings the optional response actually introduced.

    A required finding is pre-existing only when every page it locates is
    byte-for-byte unchanged since the reviewed baseline, or when its own
    reviewer linked it (carried_findings) to an overlapping baseline finding
    of the same review that was not reported regressed. Severity drift on an
    old issue therefore does not discard a reviewed improvement; anything the
    reviewers did not tie to the baseline still counts as new.
    """
    comparison=receipt.get('visual',{}).get('design_comparison') or {}
    regressed=set(comparison.get('regression_findings') or [])
    regressed_prior={r.get('id') for r in comparison.get('resolutions') or [] if r.get('status')=='regressed'}
    introduced=[];carried=[]
    for kind in ('content','visual'):
        prior={f['id']:f for f in baseline_receipt.get(kind,{}).get('findings',[])}
        if kind=='visual':
            # Visual comparison IDs may be source-qualified ("visual:F1").
            prior.update({'visual:'+i:f for i,f in list(prior.items())})
            prior.update({'content:'+f['id']:f for f in baseline_receipt.get('content',{}).get('findings',[])})
        links={row.get('id'):row.get('prior_id') for row in receipt[kind].get('carried_findings') or [] if isinstance(row,dict)}
        for f in receipt[kind]['findings']:
            if f['severity']!='required':continue
            pages=set(f['pages'])
            source=links.get(f['id'])
            linked=(source in prior and pages&set(prior[source]['pages'])
                    and not (kind=='visual' and (f['id'] in regressed or source in regressed_prior)))
            row={'review':kind,'id':f['id'],'pages':sorted(pages)}
            if pages<=set(unchanged):carried.append({**row,'evidence':'pages_unchanged'})
            elif linked:carried.append({**row,'evidence':'reviewer_link','prior_id':source})
            else:introduced.append(row)
    return introduced,carried


def restore_baseline(run,artifact,receipt,metadata,*,unpack=None,prepare=None):
    """Preserve failed work and rebuild editable state from reviewed exact bytes.

    This is not a successful design repair. A host receipt records that optional
    work was not applied. Lease/revision checks remain the caller's responsibility.
    """
    if hashlib.sha256(artifact).hexdigest()!=receipt['artifact_sha256']:
        raise ValueError('Optional refinement baseline hash changed')
    from repair_bootstrap import bootstrap_repair_workspace
    from tool_preparation import prepare_tool_manifest
    job=Path(run.job).resolve(strict=True)
    home=job/('designer-fallback-'+uuid.uuid4().hex);home.mkdir(mode=0o700)
    result=bootstrap_repair_workspace(home,run.cfg,artifact=artifact,
        artifact_sha256=receipt['artifact_sha256'],task_id=run.task['id'],
        input_revision=receipt['input_revision'],plugin_version=receipt['plugin_version'],
        repair_round=receipt['round'],unpack=unpack)
    def replace(name,body):
        destination=job/name
        if destination.is_symlink():raise ValueError('Unsafe optional-refinement metadata')
        temporary=job/('.designer-restore-'+uuid.uuid4().hex)
        with temporary.open('xb') as stream:stream.write(body)
        os.replace(temporary,destination)
    for name,body in metadata.items():
        current=job/name
        if current.is_file() and not current.is_symlink():
            # Preserve even an oversized/half-written optional attempt without
            # making its parseability a prerequisite for restoring accepted data.
            os.replace(current,home/('attempted-'+name))
        if body is None:
            if current.is_symlink():raise ValueError('Unsafe optional-refinement metadata')
            current.unlink(missing_ok=True)
        else:replace(name,body)
    replace('delivery.json',json.dumps({'path':result['candidate_path'],'workspace':result['workspace']}).encode())
    target={key:result[key] for key in ('binding','workspace','candidate_path','receipt_path','partial_edits_retained')}
    replace('repair-target.json',json.dumps(target).encode())
    (prepare or prepare_tool_manifest)(run.cfg,job,workspace=result['workspace'])
    response={'status':'not_applied','reason':'optional_refinement_failed',
              'artifact_sha256':receipt['artifact_sha256'],'round':receipt['round']}
    response_path=home/'designer-response.json';response_path.write_text(json.dumps(response))
    return [str(Path(result['candidate_path']).relative_to(job)),'delivery.json',
            str(response_path.relative_to(job)),'repair-target.json']
