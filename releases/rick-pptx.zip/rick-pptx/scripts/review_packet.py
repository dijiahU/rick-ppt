"""Collect factual native-review evidence from a validated workspace (no scoring)."""
import argparse
import json
import shutil
import tempfile
from pathlib import Path
from lxml import etree
from PIL import Image, ImageOps, ImageDraw
from pptx_core.common import parse, NS, local, atomic_json, sha256, PptxError
from pptx_core.package import select,pack
from pptx_core.relationships import slide_parts, relationships
from pptx_core.renderer import render_package
from native_structure import identity, bounds


def collect_interactive(ws, destination):
    from native_policy import validate_native
    return validate_native(ws.root)


def simple_appear_steps(tree):
    from native_builds import appear_steps
    return appear_steps(tree)


def state_previews(root,parts,destination):
    destination=Path(destination).resolve()
    plans={};skipped=[]
    for number,part in enumerate(parts,1):
        steps=simple_appear_steps(parse(root/part))
        if steps:plans[number]=(steps,sorted({0,len(steps)//2,len(steps)-1}))
        elif steps is None:skipped.append(number)
    if not plans:return {'frames':[],'unsupported_pages':skipped}
    frames=[]
    with tempfile.TemporaryDirectory(prefix='.review-states-',dir=destination) as temp:
        temp=Path(temp)
        for slot in range(max(len(indices) for steps,indices in plans.values())):
            copied=temp/f'copy-{slot}';shutil.copytree(root,copied)
            selections={}
            for number,(steps,indices) in plans.items():
                if slot>=len(indices):continue
                shown=indices[slot];selections[number]=shown
                path=copied/parts[number-1];tree=parse(path);timing=tree.find('p:timing',NS);tree.remove(timing)
                hidden={i for group in steps[shown:] for i in group}
                for node in list(tree.iter()):
                    if local(node) not in ('sp','pic','graphicFrame','grpSp','cxnSp'):continue
                    prop=next((n for n in node.iter() if local(n)=='cNvPr'),None)
                    if prop is not None and prop.get('id') in hidden and node.getparent() is not None:node.getparent().remove(node)
                path.write_bytes(etree.tostring(tree,xml_declaration=True,encoding='UTF-8',standalone=True))
            package=temp/f'states-{slot}.pptx';pack(copied,package)
            rendered=render_package(package,temp/f'render-{slot}',expected_pages=len(parts))
            for number,shown in selections.items():
                name=f'state-page-{number}-after-{shown}.png';shutil.copyfile(rendered['pages'][number-1],destination/name)
                frames.append({'page':number,'after_clicks':shown,'file':name,'total_clicks':len(plans[number][0])})
    return {'frames':frames,'unsupported_pages':skipped,'limitation':'Static simulations for simple whole-shape Appear builds only: future shapes removed from separate copies. Sampled initial/middle/pre-final states, not actual playback or every effect.'}


def collect(workspace, render, destination):
    ws=select(workspace); root=ws.root
    destination=Path(destination).resolve(); destination.mkdir(parents=True,exist_ok=True)
    pages=slide_parts(root)
    if len(render['pages'])!=len(pages):raise ValueError('Render/page count mismatch')
    records=[];tiles=[];reveal_steps=[]
    for number,(part,png) in enumerate(zip(pages,render['pages']),1):
        tree=parse(root/part)
        reveal_steps.append(simple_appear_steps(tree))
        shapes=[]
        for node in tree.iter():
            if local(node) not in ('sp','pic','graphicFrame','grpSp','cxnSp'):continue
            prop=identity(node)
            owner=identity(node.getparent()) if local(node.getparent())=='grpSp' else None
            sizes=sorted({int(x.get('sz'))/100 for x in node.iter() if x.get('sz') is not None and local(x) in ('rPr','defRPr','endParaRPr')})
            try:geometry=list(bounds(node))
            except PptxError:geometry=None
            shapes.append({'id':prop.get('id') if prop is not None else None,'kind':local(node),
                           'name':prop.get('name') if prop is not None else None,
                           'group_id':owner.get('id') if owner is not None else None,
                           'bounds_in_parent_emu':geometry,'explicit_font_points':sizes,
                           'connections':[{'end':local(x),**dict(x.attrib)} for x in node.iter() if local(x) in ('stCxn','endCxn')],
                           'text':' '.join(x.text or '' for x in node.iter() if local(x)=='t')})
        timing=tree.find('p:timing',NS)
        targets=[] if timing is None else [x.get('spid') for x in timing.iter() if local(x)=='spTgt']
        clicks=[] if timing is None else [dict(x.attrib) for x in timing.iter() if local(x)=='cTn' and x.get('nodeType') in ('clickEffect','withEffect','afterEffect')]
        rels=relationships(root,part)
        record={'page':number,'part':part,'text':'\n'.join(x.text or '' for x in tree.iter() if local(x)=='t'),
                'shapes':shapes,'timing_targets':targets,'effect_nodes':clicks,
                'media':[r for r in rels if any(k in r.get('type','').lower() for k in ('image','audio','video','media'))],
                'playback_verified':False}
        record['editability']={'groups':sum(s['kind']=='grpSp' for s in shapes),
            'connectors':sum(s['kind']=='cxnSp' for s in shapes),
            'unanchored_connector_ids':[s['id'] for s in shapes if s['kind']=='cxnSp' and len(s['connections'])<2]}
        records.append(record)
        with Image.open(png) as im:
            reading=im.convert('RGB').resize((900,max(1,round(im.height*900/im.width))),Image.Resampling.LANCZOS)
            name=f'reading-page-{number}.png';reading.save(destination/name)
            record['reading_preview']={'file':name,'width':reading.width,'height':reading.height,'purpose':'Scaled reading check; inspect the full-size render for detail. No automatic readability verdict.'}
            tile=Image.new('RGB',(420,260),'white'); im=ImageOps.contain(im.convert('RGB'),(410,231))
            tile.paste(im,((420-im.width)//2,5));ImageDraw.Draw(tile).text((10,241),str(number),fill='black');tiles.append(tile)
    # Bounded contact sheets; actual PNGs remain the full-size review source.
    sheets=[]
    for offset in range(0,len(tiles),12):
        group=tiles[offset:offset+12];sheet=Image.new('RGB',(1260,260*((len(group)+2)//3)), '#dddddd')
        for n,tile in enumerate(group):sheet.paste(tile,((n%3)*420,(n//3)*260))
        name=f'contact-{offset//12+1}.jpg';sheet.save(destination/name,quality=90);sheets.append(name)
    value={'slides':records,'contact_sheets':sheets,'playback':'Real playback not verified.'}
    value['interactive'] = collect_interactive(ws,destination)
    try:value['static_states']=state_previews(root,pages,destination)
    except Exception as error:value['static_states']={'frames':[],'error':type(error).__name__,'limitation':'Static state rendering failed; only final pages and timing inventory are available.'}
    atomic_json(destination/'inventory.json',value)
    from review_index import write_review_index
    write_review_index(value,render,destination,reveal_steps)
    return value

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--workspace',required=True);p.add_argument('--render-json',required=True);p.add_argument('--out',required=True)
    a=p.parse_args();value=collect(a.workspace,json.loads(Path(a.render_json).read_text()),a.out)
    print(json.dumps({'pages':len(value['slides']),'inventory':str(Path(a.out)/'inventory.json'),
                      'review_index':str(Path(a.out)/'review-index.json'),
                      'object_index':str(Path(a.out)/'review-objects.json')}))
